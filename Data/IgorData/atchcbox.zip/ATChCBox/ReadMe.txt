In this zip you will find
two folders
a)Demo 
  with a project and the source of component that you can use without registering it
  so you can check if you like it (I hate instaling components just to see their use)
b)Component
  with the source of the component for instalation

Tsourinakis Antonis
Pireaus Greece
tsoyran@otenet.gr
http://users.otenet.gr/~tsoyran/index.htm
 